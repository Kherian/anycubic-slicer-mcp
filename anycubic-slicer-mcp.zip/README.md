# Anycubic Slicer Next MCP Server (v0.1 — núcleo de presets)

MCP Server para o Claude ler, comparar e editar com segurança os presets
(machine/filament/process) do **Anycubic Slicer Next**, usado com a
**Kobra S1 + ACE Pro**. Construído a partir do código-fonte oficial
(`ANYCUBIC-3D/AnycubicSlicerNext`, AGPL-3.0), sem depender de nenhum
arquivo pessoal.

## O que já está pronto e TESTADO com dados reais

Todo o núcleo (`preset_engine.py`) foi testado contra os presets oficiais
reais da Kobra S1 vindos do repositório-fonte
(`resources/profiles/Anycubic/{machine,process}/*.json`):

- Leitura de presets e listagem por tipo.
- **Resolução da cadeia de `inherits`** (ex.: `0.20mm Standard @Anycubic
  Kobra S1 0.4 nozzle` → `fdm_process_common`) com valores efetivos finais.
- `get_setting` / `get_settings` (consulta de uma ou várias chaves).
- `compare_profiles` (diff entre dois presets, ignorando metadados).
- `clone_profile` (cria preset de usuário herdando do original).
- `propose_profile_patch` → `validate_profile_patch` → `apply_profile_patch`
  → `rollback_profile`, com backup versionado automático em
  `.asn_mcp_history/` antes de cada gravação.
- **Exportação e importação real de bundle `.orca_printer`/`.anycubic_printer`**
  (zip com `bundle_structure.json` + pastas `printer/filament/process`) —
  formato confirmado linha a linha em `CreatePresetsDialog.cpp` do código
  oficial, com round-trip testado (exportei um bundle real e reimportei).
- Catálogo semântico PT-BR ↔ chave JSON (seed com ~20 entradas, todas
  conferidas nos presets oficiais reais — não é adivinhação).
- Servidor MCP com as 17 tools da spec v1, testado com chamadas reais via
  `mcp.call_tool(...)` (ver `test_server_integration.py`).

## O que NÃO está pronto ainda

- **`get_active_printer/filament/process_profile`**: não implementado. O
  Anycubic Slicer Next guarda o "último preset selecionado" na configuração
  interna do app (provavelmente um `.conf`/`.ini`), que ainda não localizei
  e não faz parte do formato de preset em si. Precisa de investigação
  adicional na sua instalação real.
- **Caminhos reais de `ASN_SYSTEM_DIR` / `ASN_USER_DIR` na sua máquina**:
  ainda não confirmados para a sua instalação específica (AppImage, Flatpak
  ou build nativa mudam o caminho). Ver seção "Primeiro passo" abaixo.
- Fase 2 da spec (`open_project`, `slice_project`, `get_slice_statistics`
  etc.) — não implementada, como a própria spec definiu como posterior.
- Controle direto da impressora/ACE Pro — fora do escopo v1, como definido.
- O catálogo semântico tem ~20 entradas; a spec prevê dezenas. Cresce por
  demanda, sempre lastreado em presets/código reais.

## Instalação

```bash
cd anycubic-slicer-mcp
python3 -m venv .venv
source .venv/bin/activate      # Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

## Caminhos reais confirmados (macOS, usuário kgracher)

Confirmados a partir de uma busca real na máquina — não são mais suposição:

```
ASN_SYSTEM_DIR = ~/Library/Application Support/AnycubicSlicerNext/system/Anycubic
ASN_USER_DIR   = ~/Library/Application Support/AnycubicSlicerNext/user/744598
```

Ou seja, os presets do sistema NÃO ficam dentro do `.app` (correção em
relação à versão anterior deste README) — ficam soltos em
`Application Support`, junto com o `.conf` do app. `744598` é o ID de
usuário local do Anycubic Slicer Next nesta máquina.

Existem também (não usados por este MCP por enquanto, mas documentados):
- `ota/profiles/Anycubic/` — espelho de perfis sincronizado (provavelmente via cloud/OTA).
- `user_backup-v2.0.0.3/744598/` — backup automático feito pelo próprio
  Anycubic Slicer Next numa atualização de versão anterior.

Se algum dia os presets do sistema não forem encontrados em `ASN_SYSTEM_DIR`
acima (ex.: após um update do app), o `ota/profiles/Anycubic` é o primeiro
lugar a checar como fallback.

## Configuração no Claude Desktop (macOS)

Edite: `~/Library/Application Support/Claude/claude_desktop_config.json`

Este MCP (presets) e o `anycubic-cloud-mcp` (controle ACE Pro/impressora)
são complementares e podem rodar lado a lado no mesmo config — o primeiro
lê/edita configurações, o segundo controla a impressora de verdade:

```json
{
  "mcpServers": {
    "anycubic-slicer-next": {
      "command": "/caminho/para/.venv/bin/python3",
      "args": ["-m", "asn_mcp.server"],
      "env": {
        "ASN_SYSTEM_DIR": "/Users/kgracher/Library/Application Support/AnycubicSlicerNext/system/Anycubic",
        "ASN_USER_DIR": "/Users/kgracher/Library/Application Support/AnycubicSlicerNext/user/744598"
      }
    },
    "anycubic-cloud": {
      "command": "anycubic-cloud-mcp",
      "env": {
        "ANYCUBIC_AUTH_MODE": "slicer"
      }
    }
  }
}
```

Para o `anycubic-cloud`, instale primeiro (`pipx install anycubic-cloud-mcp`)
e extraia o token uma vez com `anycubic-slicer-token` (ele já sabe ler
`~/Library/Application Support/AnycubicSlicerNext/AnycubicSlicerNext.conf`
automaticamente no macOS). Veja o `README` do projeto original em
https://github.com/aegis-agent/anycubic-cloud-mcp para os detalhes de auth.

Reinicie o Claude Desktop. As 17 tools de presets + as ~19 tools de
controle/ACE devem aparecer disponíveis na conversa.

## Testando sem instalar (reproduz os testes que já rodei)

```bash
python3 test_engine_real_data.py        # motor puro, sem MCP
python3 test_server_integration.py      # servidor MCP completo
```

Ambos usam uma cópia dos presets oficiais reais da Kobra S1 (não precisa
da sua instalação para isso — só para uso real depois).

## Primeiro teste real (depois de configurar e reiniciar o Claude Desktop)

Numa conversa nova, com o MCP conectado, peça diretamente — sem colar nenhum
JSON, é para isso que o MCP existe:

> "Rode get_slicer_info e depois liste meus process profiles"

> "Resolva o perfil 'Chaveiro Reforçado' e me mostre support_top_z_distance,
> wall_loops e sparse_infill_density"

Se isso funcionar, o núcleo está validado contra seus arquivos reais — só
aí valeria reportar aqui qualquer erro específico de parsing.

## Adendo: fatiamento real (`get_model_info`, `slice_model`, `compare_slice_configs`)

Validado de ponta a ponta: baixei o OrcaSlicer oficial, fatiei um cubo de
teste real via linha de comando headless (sem interface gráfica), e
confirmei que o `AnycubicSlicerNext.app` do usuário preserva a mesma
interface de linha de comando (`--help` rodado na máquina real bateu com
o testado). Testei inclusive o cenário de comparação (20% vs 50% infill —
infill maior realmente gastou mais material e tempo, como esperado).

**3 tools novas:**
- `get_model_info(model_path)` — lê dimensões/geometria de um STL/3MF sem fatiar.
- `slice_model(model_path, printer_name, process_name, filament_names, label?)`
  — fatia de verdade com presets reais (pelo nome), retorna tempo estimado
  e consumo de filamento (gramas, calculado a partir da densidade do
  preset de filamento) — dados reais lidos do G-code gerado, não estimativa.
- `compare_slice_configs(model_path, configs=[...])` — fatia a mesma peça
  com várias combinações de preset e devolve os resultados lado a lado.

**Configuração adicional necessária** — mais uma variável de ambiente,
`ASN_BINARY_PATH`, apontando para o executável real dentro do `.app`:

```json
"env": {
  "ASN_SYSTEM_DIR": "...",
  "ASN_USER_DIR": "...",
  "ASN_BINARY_PATH": "/Applications/AnycubicSlicerNext.app/Contents/MacOS/AnycubicSlicerNext"
}
```

(o nome exato do executável dentro de `Contents/MacOS/` pode variar — rode
`ls "/Applications/AnycubicSlicerNext.app/Contents/MacOS/"` pra confirmar)

**Limitações honestas:**
- Cada chamada usa uma pasta temporária descartável (`--datadir`/`--outputdir`)
  — não deveria interferir com a sessão aberta do programa, mas isso não
  foi testado com o Anycubic Slicer Next aberto ao mesmo tempo.
- Peças complexas podem demorar bem mais que o cubo de teste — sem timeout
  configurado no lado do Claude Desktop, uma chamada muito longa pode expirar.
- O parsing dos dados de tempo/filamento é baseado em comentários de texto
  no G-code cujo formato **não é documentado oficialmente** — pode variar
  entre versões do slicer. Testado apenas na v2.4.2 (OrcaSlicer) / 2.0.0.3
  (Anycubic Slicer Next, via `--help`; fatiamento real ainda não testado
  nessa versão específica).

## Próximos passos sugeridos

1. ~~Rodar `get_slicer_info` no seu ambiente real para confirmar os caminhos~~ — feito, ver seção acima.
2. Testar `list_process_profiles` / `resolve_profile` contra seus próprios
   perfis (`Chaveiro Reforçado`, `Chaveiro Semi-Reforçado`) direto pelo
   Claude Desktop e me reportar qualquer erro de parsing — pode haver
   chaves específicas de build que eu não previ.

---

## Adendo: controle de luz (experimental) — `asn_mcp/experimental/`

Depois de investigar o código-fonte real do `anycubic_cloud_api` (a
biblioteca por baixo do `anycubic-cloud-mcp`), segui esta ordem de
tentativa: **câmera primeiro, depois luz**, com a regra de abandonar o que
não tivesse solução fácil.

### Câmera: DESCARTADA — não é um problema fácil de resolver

O comando `CAMERA_OPEN` (order_id 1001) existe e retorna credenciais
temporárias estilo AWS STS (`secret_id`, `secret_key`, `session_token`,
`region`), o que indica que o streaming passa por **AWS Kinesis Video
Streams**. Isso é bem mais do que "chamar uma função a mais": procurei em
todo o código-fonte disponível e **não existe em lugar nenhum a
correlação entre essa credencial e o nome/ARN do stream de Kinesis** ao
qual ela dá acesso. Sem isso, a credencial é inútil — não dá pra montar
uma sessão do Kinesis sem saber qual stream pedir. Isso não é um bug de
código, é uma peça de protocolo que ninguém documentou/capturou ainda
(exigiria interceptar tráfego do app oficial da Anycubic). Por isso,
conforme sua instrução, abandonei a câmera aqui.

### Luz da câmara: construída e testada em MODELO CONTROLADO (mock)

O comando `SET_LIGHT_STATUS` (1233) é simples — um único parâmetro
on/off — e a impressora já expõe flags reais de capacidade
(`supports_function_box_light`, `supports_function_video_light`) que dá
pra checar ANTES de tentar. Construí:

- `asn_mcp/experimental/light_control.py` — lógica central, com:
  - checagem de capacidade antes de agir (recusa se a impressora não
    anunciar suporte);
  - checagem de que existe um "projeto" associado (o protocolo exige
    isso, mesmo fora de uma impressão ativa);
  - tentativa de confirmação pós-comando, com aviso honesto quando não
    consegue confirmar.
- `asn_mcp/experimental/light_server.py` — servidor MCP com 2 tools:
  `get_light_capabilities` (leitura) e `set_chamber_light` (escrita,
  experimental).
- `test_light_control_mocked.py` — 4 testes com um client MOCKADO (sem
  rede, sem impressora real): capacidades, envio de comando com
  parâmetros corretos, recusa por falta de suporte, e erro claro por
  falta de projeto. **Todos passaram.**

**Limitação encontrada e NÃO resolvida (correto, pela sua regra, deixar
para depois):** a confirmação de que a luz realmente mudou de estado
chega de forma assíncrona via MQTT (`process_mqtt_update` no código da
lib), mas a lib não sabe interpretar esse tipo específico de mensagem
(cairia num branch de "dado não tratado"). Resolver isso direito exigiria
capturar uma mensagem MQTT real de status de luz para entender seu
formato — não dá pra fazer isso às cegas sem uma impressora real emitindo
esse evento. Por isso, `set_chamber_light` sempre retorna um campo
`warning` avisando que o comando foi *enviado*, não que foi *confirmado*.

### Como testar (você precisa fazer isso — eu não tenho impressora real)

```bash
pip install -r requirements-experimental.txt   # instala anycubic-cloud-mcp como dependência
anycubic-slicer-token                          # extrai o token do seu Slicer Next
```

Adicione ao `claude_desktop_config.json`:
```json
"anycubic-light-experimental": {
  "command": "/caminho/para/.venv/bin/python3",
  "args": ["-m", "asn_mcp.experimental.light_server"],
  "env": {
    "ANYCUBIC_AUTH_MODE": "slicer",
    "ANYCUBIC_TOKEN": "<token extraído acima>"
  }
}
```

Depois, numa conversa nova: *"Verifique as capacidades de luz da minha
impressora e tente ligar a luz da câmara."* — e me diga exatamente o que
aconteceu (incluindo se a luz realmente acendeu de verdade). Essa parte
só você pode validar.
3. Expandir o catálogo semântico (`seed_catalog()` em `preset_engine.py`)
   conforme os problemas reais de impressão forem aparecendo.
4. Investigar `get_active_*_profile` (provavelmente requer ler o `.conf`
   principal do app, não os presets).
