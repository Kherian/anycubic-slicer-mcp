"""Funcionalidades experimentais e NÃO validadas contra hardware real.

Use com cautela. Cada módulo aqui documenta seu próprio nível de confiança.
"""
