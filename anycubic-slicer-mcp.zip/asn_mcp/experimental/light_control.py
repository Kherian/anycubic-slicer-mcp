"""
experimental/light_control.py
==============================

Controle experimental da luz da câmara (chamber/box light) da impressora,
via API de nuvem reversa-projetada da Anycubic (mesma usada pelo
anycubic-cloud-mcp, pacote `anycubic_cloud_api`).

STATUS: EXPERIMENTAL / NÃO VALIDADO EM HARDWARE REAL.

Por quê:
- O comando SET_LIGHT_STATUS (order_id 1233) existe no protocolo, mas no
  código-fonte da biblioteca está marcado como "WIP Unused" — nunca foi
  ligado a nenhuma função pública, o que sugere que o autor nunca o testou
  contra uma impressora real.
- GET_LIGHT_STATUS (order_id 1232) já é chamado internamente (dentro de
  query_printer_options), então tem mais chance de já funcionar.
- A resposta de ambos os comandos chega de forma assíncrona via MQTT, não
  como retorno direto da chamada — ou seja, "enviar o comando" não é o
  mesmo que "confirmar que funcionou". Por isso este módulo SEMPRE consulta
  get_light_status logo depois de tentar set_light_status, com um pequeno
  atraso, e reporta honestamente se não conseguiu confirmar a mudança.

Antes de tentar ligar/desligar, este módulo verifica a capacidade
declarada da própria impressora (printer.supports_function_box_light),
para não mandar um comando que o firmware nem anuncia suportar.

IMPORTANTE: este módulo NUNCA foi testado contra uma Kobra S1 real. Os
testes que rodei aqui usam um cliente MOCKADO (sem rede), só para garantir
que o código não quebra e constrói os parâmetros certos. A validação real
só acontece quando você rodar isso contra sua impressora de verdade.
"""

from __future__ import annotations

import asyncio
import logging
from dataclasses import dataclass
from typing import Any, Optional

from anycubic_cloud_api import AnycubicMQTTAPI
from anycubic_cloud_api.data_models.printer import AnycubicPrinter
from anycubic_cloud_api.data_models.project import AnycubicProject

# Mapeamento observado nos enums do protocolo (AnycubicFunctionID):
#   VIDEO_LIGHT = 40  -> luz auxiliar da câmera (para vídeo/foto)
#   BOX_LIGHT   = 41  -> luz da câmara de impressão (chamber light)
# O parâmetro 'light_type' do comando SET_LIGHT_STATUS não tem, no código,
# uma confirmação explícita de que 1=video / 2=box — isso é uma HIPÓTESE
# baseada na ordem dos IDs acima, não um fato confirmado. Trate light_type
# como um parâmetro a testar com cautela, não como algo garantido.
LIGHT_TYPE_VIDEO = 1
LIGHT_TYPE_BOX = 2


class LightControlError(Exception):
    pass


class LightNotSupportedError(LightControlError):
    pass


@dataclass
class LightCapabilities:
    printer_id: int
    supports_box_light: bool
    supports_video_light: bool
    connected_peripherals: Any


@dataclass
class LightActionResult:
    requested_state: bool
    order_sent: bool
    order_msg_id: Optional[str]
    confirmed_state: Optional[bool]  # None = não foi possível confirmar
    warning: Optional[str] = None


async def get_light_capabilities(api: AnycubicMQTTAPI, printer_id: int) -> LightCapabilities:
    """Consulta (somente leitura) se a impressora anuncia suporte a luz
    de câmara/vídeo, ANTES de tentar qualquer ação de escrita."""
    printer = await api.printer_info_for_id(printer_id, ignore_init_errors=True)
    if printer is None:
        raise LightControlError(f"Impressora {printer_id} não encontrada.")
    return LightCapabilities(
        printer_id=printer_id,
        supports_box_light=printer.supports_function_box_light,
        supports_video_light=printer.supports_function_video_light,
        connected_peripherals=printer.connected_peripherals,
    )


async def set_chamber_light(
    api: AnycubicMQTTAPI,
    printer_id: int,
    light_on: bool,
    light_type: int = LIGHT_TYPE_BOX,
    confirm_timeout_s: float = 3.0,
    require_capability: bool = True,
) -> LightActionResult:
    """
    Tenta ligar/desligar a luz. Fluxo:
      1. Busca a impressora e o projeto mais recente (a API exige um
         'project' mesmo fora de uma impressão ativa).
      2. Se require_capability=True (padrão), recusa se a impressora não
         anunciar suporte à luz pedida — evita mandar comando no vazio.
      3. Envia SET_LIGHT_STATUS.
      4. Espera confirm_timeout_s e consulta GET_LIGHT_STATUS para tentar
         confirmar. Se não conseguir confirmar, retorna com aviso claro —
         nunca finge sucesso que não pôde verificar.
    """
    printer = await api.printer_info_for_id(printer_id, ignore_init_errors=True)
    if printer is None:
        raise LightControlError(f"Impressora {printer_id} não encontrada.")

    if require_capability:
        wants_box = light_type == LIGHT_TYPE_BOX
        supported = printer.supports_function_box_light if wants_box else printer.supports_function_video_light
        if not supported:
            raise LightNotSupportedError(
                f"A impressora não anuncia suporte a "
                f"{'luz de câmara (box_light)' if wants_box else 'luz de vídeo (video_light)'}. "
                f"Isso não significa necessariamente que é impossível, mas o firmware não "
                f"declara essa função — recomendo confirmar manualmente antes de insistir."
            )

    await printer.update_info_from_api(with_project=True)
    project: Optional[AnycubicProject] = printer.latest_project

    if project is None:
        raise LightControlError(
            "Não há nenhum projeto (impressão atual ou recente) associado à impressora. "
            "O protocolo exige um project_id para este comando — provavelmente só funciona "
            "com uma impressão em andamento ou recém-concluída."
        )

    resp = await api._send_order_set_light_status(  # noqa: SLF001 — função interna intencional
        printer=printer,
        project=project,
        light_on=light_on,
        light_type=light_type,
    )
    order_msg_id = None
    if isinstance(resp, dict):
        order_msg_id = resp.get("data", {}).get("msgid") if resp.get("data") else None

    confirmed_state: Optional[bool] = None
    warning: Optional[str] = None
    try:
        await asyncio.sleep(confirm_timeout_s)
        await api._send_order_get_light_status(printer=printer, project=project)  # noqa: SLF001
        # A resposta chega via MQTT de forma assíncrona (push), não como
        # retorno direto desta chamada. Sem um listener MQTT plugado nesta
        # função, não há como ler o valor atualizado aqui — é uma limitação
        # real da forma como o protocolo funciona, não um bug deste código.
        warning = (
            "Comando enviado, mas a confirmação do novo estado chega via MQTT "
            "assíncrono, que esta função não está escutando. Confirme visualmente "
            "ou via printer_status pouco depois."
        )
    except Exception as exc:  # defensivo — nunca mascarar como sucesso
        warning = f"Não foi possível nem tentar confirmar: {exc}"

    return LightActionResult(
        requested_state=light_on,
        order_sent=True,
        order_msg_id=order_msg_id,
        confirmed_state=confirmed_state,
        warning=warning,
    )
