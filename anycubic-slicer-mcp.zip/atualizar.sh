#!/bin/bash
# atualizar.sh — atualiza o código do Anycubic Slicer Next MCP sem mexer
# nos .venv nem no claude_desktop_config.json.
#
# Uso: salve o anycubic-slicer-mcp.zip novo em ~/Downloads (não precisa
# renomear nem descompactar) e rode:
#
#   bash ~/anycubic-slicer-mcp/atualizar.sh
#
# O script acha sozinho o zip mais recente em ~/Downloads.

set -e

PROJECT_DIR="$HOME/anycubic-slicer-mcp"
DOWNLOADS="$HOME/Downloads"

echo "🔍 Procurando o zip mais recente em $DOWNLOADS..."
ZIP_PATH=$(ls -t "$DOWNLOADS"/anycubic-slicer-mcp*.zip 2>/dev/null | head -n 1)

if [ -z "$ZIP_PATH" ]; then
    echo "❌ Não encontrei nenhum arquivo 'anycubic-slicer-mcp*.zip' em $DOWNLOADS."
    echo "   Baixe o zip mais recente primeiro (sem precisar renomear) e rode este script de novo."
    exit 1
fi

echo "✅ Encontrado: $ZIP_PATH"

if [ ! -d "$PROJECT_DIR" ]; then
    echo "❌ Não encontrei a instalação em $PROJECT_DIR."
    echo "   Isso parece ser uma instalação nova, não uma atualização — siga as"
    echo "   instruções completas de instalação em vez deste script."
    exit 1
fi

cd "$PROJECT_DIR"

BACKUP_DIR="asn_mcp.backup-$(date +%Y%m%d-%H%M%S)"
if [ -d "asn_mcp" ]; then
    echo "📦 Guardando uma cópia de segurança do código atual em: $BACKUP_DIR"
    mv asn_mcp "$BACKUP_DIR"
fi

echo "📂 Extraindo o código novo..."
unzip -q -o "$ZIP_PATH" "asn_mcp/*" -d "$PROJECT_DIR"

# Requirements podem ter mudado entre versões -- reinstala por garantia,
# sem recriar os venvs do zero (rápido se nada mudou).
if [ -f "requirements.txt" ]; then
    echo "📦 Conferindo dependências do ambiente principal (.venv)..."
    unzip -q -o "$ZIP_PATH" "requirements.txt" "requirements-experimental.txt" -d "$PROJECT_DIR" 2>/dev/null || true
    .venv/bin/pip install -q -r requirements.txt
    if [ -f "requirements-experimental.txt" ]; then
        .venv/bin/pip install -q -r requirements-experimental.txt
    fi
fi

echo ""
echo "✅ Atualizado com sucesso!"
echo ""
echo "Próximo passo: feche o Claude Desktop COMPLETAMENTE (⌘Q, não só a janela)"
echo "e abra de novo. Não precisa mexer em mais nada — seu claude_desktop_config.json"
echo "e seus dois .venv continuam exatamente como estavam."
echo ""
echo "(Se algo der errado, seu código antigo está salvo em: $PROJECT_DIR/$BACKUP_DIR)"

# Garante que este próprio script já fica atualizado para a próxima vez,
# sem precisar repetir o passo de extração manual de novo.
unzip -q -o "$ZIP_PATH" "atualizar.sh" -d "$PROJECT_DIR" 2>/dev/null || true
chmod +x "$PROJECT_DIR/atualizar.sh" 2>/dev/null || true
