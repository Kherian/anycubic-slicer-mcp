"""
server.py — Anycubic Slicer Next MCP Server

Expõe, como tools MCP, o motor de presets (preset_engine.py) já testado
contra os presets oficiais reais da Kobra S1.

Separação de estados exigida na spec:
  READ    -> list_*_profiles, get_profile, resolve_profile, get_setting(s),
             compare_profiles, get_slicer_info
  PROPOSE -> propose_profile_patch, validate_profile_patch  (nada é gravado)
  APPLY   -> apply_profile_patch, clone_profile, rollback_profile,
             export_anycubic_bundle, import_anycubic_bundle (grava em disco)

Configuração via variáveis de ambiente (definidas no config do Claude Desktop):
  ASN_SYSTEM_DIR   -> diretório de presets 'system' do Anycubic Slicer Next
                       (os que vêm com o programa)
  ASN_USER_DIR     -> diretório de presets 'user' (onde o MCP também escreve)
  ASN_CATALOG_PATH -> (opcional) caminho para um catalogo_semantico.json
                       próprio; se ausente, usa o catálogo-semente embutido.

Localização típica de ASN_SYSTEM_DIR / ASN_USER_DIR (ainda não confirmada
empiricamente na sua instalação específica — primeira coisa a validar):
  Windows: %AppData%\\AnycubicSlicerNext\\...\\resources\\profiles\\Anycubic  (system)
           %AppData%\\AnycubicSlicerNext\\user\\<id>\\                       (user)
  Linux/AppImage/Flatpak: ~/.config/AnycubicSlicerNext/...
"""

from __future__ import annotations

import os
import platform
from pathlib import Path
from typing import Any, Dict, List, Optional

from mcp.server.mcpserver import MCPServer

from .preset_engine import (
    PresetError,
    PresetStore,
    SemanticCatalog,
    UserPresetWriter,
    export_bundle as _export_bundle,
    import_bundle as _import_bundle,
    seed_catalog,
)
from .slicing_engine import (
    SlicingError,
    compare_slice_configs as _compare_slice_configs,
    get_model_info as _get_model_info,
    slice_model as _slice_model,
)

mcp = MCPServer(
    name="anycubic-slicer-next",
    version="0.1.0",
    instructions=(
        "Servidor MCP para leitura, comparação e edição segura de presets do "
        "Anycubic Slicer Next (Kobra S1 + ACE Pro). Sempre siga o fluxo "
        "READ -> PROPOSE -> (autorização do usuário) -> APPLY. Nunca chame "
        "apply_profile_patch sem antes mostrar o diff de propose_profile_patch "
        "e obter confirmação explícita do usuário."
    ),
)


def _get_system_dir() -> Path:
    p = os.environ.get("ASN_SYSTEM_DIR")
    if not p:
        raise PresetError(
            "ASN_SYSTEM_DIR não configurado. Defina no config do MCP o caminho "
            "para a pasta de presets 'system' do Anycubic Slicer Next."
        )
    return Path(p)


def _get_user_dir() -> Path:
    p = os.environ.get("ASN_USER_DIR")
    if not p:
        raise PresetError(
            "ASN_USER_DIR não configurado. Defina no config do MCP o caminho "
            "para a pasta de presets do usuário (onde clones/patches serão gravados)."
        )
    return Path(p)


def _store() -> PresetStore:
    return PresetStore([("user", _get_user_dir()), ("system", _get_system_dir())])


def _writer() -> UserPresetWriter:
    return UserPresetWriter(_get_user_dir())


def _catalog() -> SemanticCatalog:
    custom = os.environ.get("ASN_CATALOG_PATH")
    if custom and Path(custom).exists():
        return SemanticCatalog.load_json(Path(custom))
    return seed_catalog()


# --------------------------------------------------------------------- READ

@mcp.tool()
def get_slicer_info() -> Dict[str, Any]:
    """Retorna informações sobre a instalação detectada: SO, diretórios
    configurados e se estão acessíveis. Sempre chame isso primeiro."""
    system_dir = os.environ.get("ASN_SYSTEM_DIR")
    user_dir = os.environ.get("ASN_USER_DIR")
    return {
        "os": platform.system(),
        "os_version": platform.version(),
        "asn_system_dir": system_dir,
        "asn_system_dir_exists": Path(system_dir).is_dir() if system_dir else False,
        "asn_user_dir": user_dir,
        "asn_user_dir_exists": Path(user_dir).is_dir() if user_dir else False,
        "mcp_server_version": "0.1.0",
    }


@mcp.tool()
def list_printer_profiles() -> List[str]:
    """Lista os presets de máquina (printer) disponíveis."""
    return _store().list_names("machine")


@mcp.tool()
def list_filament_profiles() -> List[str]:
    """Lista os presets de filamento disponíveis."""
    return _store().list_names("filament")


@mcp.tool()
def list_process_profiles() -> List[str]:
    """Lista os presets de processo (perfil de impressão) disponíveis."""
    return _store().list_names("process")


@mcp.tool()
def get_profile(preset_type: str, name: str) -> Dict[str, Any]:
    """Retorna o preset como gravado em disco (sem resolver inherits),
    incluindo metadados como 'inherits'. Use resolve_profile para valores efetivos."""
    record = _store().load_raw(preset_type, name)
    return {"path": str(record.path), "root": record.root_label, "raw": record.raw}


@mcp.tool()
def resolve_profile(preset_type: str, name: str) -> Dict[str, Any]:
    """Resolve toda a cadeia de 'inherits' e retorna os valores EFETIVOS finais
    (o que o slicer realmente usaria), mesmo para chaves não presentes
    explicitamente no preset do usuário."""
    return _store().resolve(preset_type, name)


@mcp.tool()
def get_setting(preset_type: str, name: str, key: str) -> Any:
    """Consulta o valor efetivo de UMA chave específica em um preset."""
    return _store().get_effective_value(preset_type, name, key)


@mcp.tool()
def get_settings(preset_type: str, name: str, keys: List[str]) -> Dict[str, Any]:
    """Consulta o valor efetivo de um CONJUNTO de chaves relacionadas
    (ex.: todas as chaves 'support_*')."""
    return _store().get_effective_values(preset_type, name, keys)


@mcp.tool()
def compare_profiles(preset_type: str, name_a: str, name_b: str) -> Dict[str, Any]:
    """Compara dois presets do mesmo tipo (valores efetivos) e retorna só as diferenças."""
    from .preset_engine import diff_effective
    store = _store()
    a = store.resolve(preset_type, name_a)
    b = store.resolve(preset_type, name_b)
    diff = diff_effective(a, b)
    return {"a": name_a, "b": name_b, "differences": {k: {"a": v[0], "b": v[1]} for k, v in diff.items()}}


@mcp.tool()
def resolve_pt_name(pt_name: str) -> Optional[Dict[str, Any]]:
    """Traduz um nome em português (como aparece na interface) para a chave
    JSON correspondente, usando o catálogo semântico."""
    entry = _catalog().resolve_pt_name(pt_name)
    return entry.__dict__ if entry else None


# ------------------------------------------------------------------ PROPOSE

@mcp.tool()
def propose_profile_patch(preset_type: str, name: str, changes: Dict[str, str]) -> Dict[str, Any]:
    """Calcula o efeito de uma mudança proposta SEM gravar nada em disco.
    'changes' é um dict {chave_json: novo_valor}. Sempre chame isto e mostre
    o diff ao usuário antes de considerar apply_profile_patch."""
    return _writer().propose_patch(_store(), preset_type, name, changes)


@mcp.tool()
def validate_profile_patch(preset_type: str, changes: Dict[str, str]) -> Dict[str, Any]:
    """Valida uma mudança proposta contra o catálogo semântico (namespace
    correto, limites conhecidos). Retorna lista de problemas (vazia = ok)."""
    problems = _writer().validate_patch(preset_type, changes, _catalog())
    return {"valid": len(problems) == 0, "problems": problems}


# -------------------------------------------------------------------- APPLY

@mcp.tool()
def clone_profile(preset_type: str, source_name: str, new_name: str) -> str:
    """Cria um novo preset de usuário herdando de 'source_name'. Nunca
    modifica o preset original. Use isto antes de aplicar qualquer patch."""
    path = _writer().clone(_store(), preset_type, source_name, new_name)
    return str(path)


@mcp.tool()
def apply_profile_patch(preset_type: str, name: str, changes: Dict[str, str]) -> Dict[str, Any]:
    """Aplica de fato as mudanças a um preset de USUÁRIO já existente (via
    clone_profile). Cria backup automático antes de gravar. SÓ chame isto
    depois de o usuário ter visto o diff de propose_profile_patch e
    confirmado explicitamente."""
    path = _writer().apply_patch(preset_type, name, changes)
    return {"path": str(path), "applied_changes": changes}


@mcp.tool()
def rollback_profile(preset_type: str, name: str) -> str:
    """Restaura o preset de usuário para o estado anterior ao último apply."""
    path = _writer().rollback(preset_type, name)
    return str(path)


@mcp.tool()
def export_anycubic_bundle(
    printer_name: str, filament_names: List[str], process_names: List[str], bundle_id: str, out_path: str
) -> str:
    """Gera um pacote .orca_printer (mesmo formato do .anycubic_printer
    exportado pela interface) contendo os presets indicados, pronto para
    reimportar no Anycubic Slicer Next."""
    store = _store()
    _, printer_path = store.find_path("machine", printer_name)
    filament_paths = [store.find_path("filament", n)[1] for n in filament_names]
    process_paths = [store.find_path("process", n)[1] for n in process_names]
    result = _export_bundle(Path(out_path), printer_path, filament_paths, process_paths, bundle_id)
    return str(result)


@mcp.tool()
def import_anycubic_bundle(bundle_path: str) -> Dict[str, Any]:
    """Lê e valida um bundle .anycubic_printer/.orca_printer exportado pelo
    Anycubic Slicer Next, sem instalá-lo — apenas retorna seu conteúdo
    estruturado para inspeção."""
    imported = _import_bundle(Path(bundle_path))
    return {
        "bundle_type": imported.bundle_structure.get("bundle_type"),
        "printer": imported.printer.get("name"),
        "filaments": [f.get("name") for f in imported.filaments],
        "processes": [p.get("name") for p in imported.processes],
    }


# --------------------------------------------------------------- SLICING
#
# Fatiamento real via linha de comando do Anycubic Slicer Next. Requer
# ASN_BINARY_PATH configurado (caminho do executável dentro do .app).
# Cada chamada usa uma pasta temporária descartável — nunca toca no seu
# perfil ativo nem na sessão aberta do programa.


def _get_binary_path() -> str:
    p = os.environ.get("ASN_BINARY_PATH")
    if not p:
        raise PresetError(
            "ASN_BINARY_PATH não configurado. Aponte para o executável dentro do "
            "AnycubicSlicerNext.app, ex.: "
            "/Applications/AnycubicSlicerNext.app/Contents/MacOS/AnycubicSlicerNext"
        )
    return p


def _filament_density(store: PresetStore, filament_name: str) -> Optional[float]:
    try:
        effective = store.resolve("filament", filament_name)
        density = effective.get("filament_density")
        if isinstance(density, list):
            density = density[0] if density else None
        return float(density) if density else None
    except Exception:
        return None


@mcp.tool()
def get_model_info(model_path: str) -> Dict[str, Any]:
    """[LEITURA, sem fatiar] Retorna dimensões, número de triângulos e se a
    malha é manifold (fechada corretamente) de um arquivo STL/3MF."""
    info = _get_model_info(_get_binary_path(), Path(model_path))
    return info.__dict__


@mcp.tool()
def slice_model(
    model_path: str,
    printer_name: str,
    process_name: str,
    filament_names: List[str],
    label: Optional[str] = None,
) -> Dict[str, Any]:
    """Fatia de verdade um arquivo STL/3MF com os presets indicados (pelo
    nome, iguais aos usados em list_process_profiles etc.) e retorna tempo
    estimado de impressão e consumo de filamento reais. Usa uma pasta
    temporária descartável — não grava nada no seu perfil ativo. Pode
    demorar de alguns segundos a minutos dependendo da complexidade do
    modelo."""
    store = _store()
    _, machine_path = store.find_path("machine", printer_name)
    _, process_path = store.find_path("process", process_name)
    filament_paths = [store.find_path("filament", n)[1] for n in filament_names]
    density = _filament_density(store, filament_names[0]) if filament_names else None

    result = _slice_model(
        binary_path=_get_binary_path(),
        model_path=Path(model_path),
        machine_preset_path=machine_path,
        process_preset_path=process_path,
        filament_preset_paths=filament_paths,
        filament_density_g_cm3=density,
        label=label,
    )
    return {
        "success": result.success,
        "error_string": result.error_string,
        "label": result.label,
        "printing_time": result.printing_time_str,
        "printing_time_minutes": result.printing_time_minutes,
        "filament_used_cm3": result.filament_used_cm3,
        "filament_used_g": result.filament_used_g,
        "warnings": result.warnings,
        "layer_height": result.layer_height,
        "sparse_infill_density": result.sparse_infill_density,
        "wall_loops": result.wall_loops,
    }


@mcp.tool()
def compare_slice_configs(
    model_path: str,
    configs: List[Dict[str, Any]],
) -> List[Dict[str, Any]]:
    """Fatia de verdade o mesmo modelo com 2 ou mais combinações de presets
    diferentes e retorna os resultados lado a lado, para comparar
    trade-offs reais (ex.: 'mais resistente vs. mais econômico'). Cada item
    de 'configs' deve ter: label, printer_name, process_name,
    filament_names (lista). ATENÇÃO: isso fatia o modelo uma vez por
    config — pode demorar."""
    store = _store()
    resolved_configs = []
    for cfg in configs:
        _, machine_path = store.find_path("machine", cfg["printer_name"])
        _, process_path = store.find_path("process", cfg["process_name"])
        filament_paths = [store.find_path("filament", n)[1] for n in cfg["filament_names"]]
        density = _filament_density(store, cfg["filament_names"][0]) if cfg.get("filament_names") else None
        resolved_configs.append({
            "label": cfg.get("label"),
            "machine_preset_path": machine_path,
            "process_preset_path": process_path,
            "filament_preset_paths": filament_paths,
            "filament_density_g_cm3": density,
        })

    results = _compare_slice_configs(_get_binary_path(), Path(model_path), resolved_configs)
    return [
        {
            "label": r.label,
            "success": r.success,
            "error_string": r.error_string,
            "printing_time": r.printing_time_str,
            "printing_time_minutes": r.printing_time_minutes,
            "filament_used_g": r.filament_used_g,
            "filament_used_cm3": r.filament_used_cm3,
            "warnings": r.warnings,
        }
        for r in results
    ]


def main() -> None:
    mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
