import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent))
from asn_mcp.slicing_engine import get_model_info, slice_model, compare_slice_configs

BINARY = "/home/claude/OrcaSlicer.AppImage"
MODEL = Path("/home/claude/slice_test/cube.stl")
PROF = Path("/home/claude/squashfs-root/resources/profiles/BBL")

print("=== get_model_info ===")
info = get_model_info(BINARY, MODEL)
print(info)
assert info.number_of_facets == 12
assert info.manifold is True
print("OK\n")

print("=== slice_model (config única) ===")
r = slice_model(
    binary_path=BINARY,
    model_path=MODEL,
    machine_preset_path=PROF / "machine/Bambu Lab X1 Carbon 0.4 nozzle.json",
    process_preset_path=PROF / "process/0.20mm Standard @BBL X1C.json",
    filament_preset_paths=[PROF / "filament/Bambu PLA Basic @BBL X1C.json"],
    filament_density_g_cm3=1.24,
    label="teste_padrao",
)
print(f"success={r.success} error={r.error_string}")
print(f"tempo total={r.printing_time_str} ({r.printing_time_minutes} min)")
print(f"filamento={r.filament_used_cm3} cm3 = {r.filament_used_g} g")
assert r.success
assert r.filament_used_g and r.filament_used_g > 0
print("OK\n")

print("=== compare_slice_configs (infill 20% vs 50%, exige clonar preset com infill diferente) ===")
# Simula duas configs: padrao (20% infill do preset original) e uma variante
# com infill mais alto -- criamos um preset de processo temporario para simular
# "mais resistencia".
import json, tempfile
variant_dir = Path(tempfile.mkdtemp())
process_raw = json.loads((PROF / "process/0.20mm Standard @BBL X1C.json").read_text())
process_raw["sparse_infill_density"] = "50%"
process_raw["name"] = "0.20mm Standard @BBL X1C (infill 50 teste)"
variant_path = variant_dir / "variant_process.json"
variant_path.write_text(json.dumps(process_raw))

results = compare_slice_configs(
    binary_path=BINARY,
    model_path=MODEL,
    configs=[
        {
            "label": "20% infill (padrao)",
            "machine_preset_path": PROF / "machine/Bambu Lab X1 Carbon 0.4 nozzle.json",
            "process_preset_path": PROF / "process/0.20mm Standard @BBL X1C.json",
            "filament_preset_paths": [PROF / "filament/Bambu PLA Basic @BBL X1C.json"],
            "filament_density_g_cm3": 1.24,
        },
        {
            "label": "50% infill (mais resistente)",
            "machine_preset_path": PROF / "machine/Bambu Lab X1 Carbon 0.4 nozzle.json",
            "process_preset_path": variant_path,
            "filament_preset_paths": [PROF / "filament/Bambu PLA Basic @BBL X1C.json"],
            "filament_density_g_cm3": 1.24,
        },
    ],
)
for r in results:
    print(f"  {r.label:35s} -> {r.filament_used_g}g, {r.printing_time_str}, sucesso={r.success}")

assert results[1].filament_used_g > results[0].filament_used_g, "infill maior deveria gastar mais material"
print("OK — infill maior realmente gastou mais material, como esperado.\n")

print("SUCESSO: motor de fatiamento validado de ponta a ponta.")
