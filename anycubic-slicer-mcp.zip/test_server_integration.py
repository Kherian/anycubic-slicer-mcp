import asyncio
import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

WORK = Path("/home/claude/asn_mcp_testdata")
os.environ["ASN_SYSTEM_DIR"] = str(WORK / "system")
os.environ["ASN_USER_DIR"] = str(WORK / "user")

from asn_mcp.server import mcp  # noqa: E402


async def main():
    tools = await mcp.list_tools()
    print(f"=== {len(tools)} tools registradas ===")
    for t in tools:
        print(f"  - {t.name}: {t.description.splitlines()[0]}")

    print("\n=== call_tool: get_slicer_info ===")
    res = await mcp.call_tool("get_slicer_info", {})
    print(" ", res)

    print("\n=== call_tool: list_process_profiles ===")
    res = await mcp.call_tool("list_process_profiles", {})
    print(" ", res)

    print("\n=== call_tool: resolve_pt_name ===")
    res = await mcp.call_tool("resolve_pt_name", {"pt_name": "Número de paredes"})
    print(" ", res)

    print("\n=== call_tool: compare_profiles ===")
    # compara o preset oficial contra o clone que criamos no teste anterior
    res = await mcp.call_tool(
        "compare_profiles",
        {"preset_type": "process", "name_a": "0.20mm Standard @Anycubic Kobra S1 0.4 nozzle",
         "name_b": "Chaveiro_SemiReforcado_teste"},
    )
    print(" ", res)


asyncio.run(main())
print("\n✅ Servidor MCP responde corretamente às chamadas de tool.")
