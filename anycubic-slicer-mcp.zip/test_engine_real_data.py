"""
Testa preset_engine.py contra os presets OFICIAIS reais da Anycubic Kobra S1,
copiados diretamente do repositório-fonte ANYCUBIC-3D/AnycubicSlicerNext.

Isso prova que o parser/resolvedor funciona em cima de dados verdadeiros do
programa, sem depender de nenhum arquivo pessoal do usuário.
"""
import shutil
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from asn_mcp.preset_engine import (  # noqa: E402
    PresetStore, UserPresetWriter, diff_effective, export_bundle, import_bundle,
    seed_catalog,
)

SRC = Path("/home/claude/AnycubicSlicerNext/resources/profiles/Anycubic")
WORK = Path("/home/claude/asn_mcp_testdata")
SYSTEM_ROOT = WORK / "system"
USER_ROOT = WORK / "user"

if WORK.exists():
    shutil.rmtree(WORK)
for t in ("machine", "filament", "process"):
    (SYSTEM_ROOT / t).mkdir(parents=True, exist_ok=True)
(USER_ROOT).mkdir(parents=True, exist_ok=True)

# Copia só o necessário para resolver a cadeia real de inherits da Kobra S1.
FILES = {
    "machine": ["Anycubic Kobra S1 0.4 nozzle.json", "fdm_machine_common.json"],
    "process": ["0.20mm Standard @Anycubic Kobra S1 0.4 nozzle.json", "fdm_process_common.json"],
    "filament": ["Anycubic PLA @Anycubic Kobra S1 0.4 nozzle.json", "fdm_filament_common.json",
                 "fdm_filament_pla_common.json"],
}
for ptype, names in FILES.items():
    for name in names:
        src = SRC / ptype / name
        if src.exists():
            shutil.copy(src, SYSTEM_ROOT / ptype / name)
        else:
            print(f"[aviso] não encontrado no repo oficial: {ptype}/{name}")

store = PresetStore([("system:Anycubic", SYSTEM_ROOT), ("user", USER_ROOT)])

print("=== list_process_profiles ===")
print(store.list_names("process"))

print("\n=== resolve_profile (process) — valores efetivos finais ===")
effective = store.resolve("process", "0.20mm Standard @Anycubic Kobra S1 0.4 nozzle")
for key in ["layer_height", "wall_loops", "support_top_z_distance", "sparse_infill_density",
            "bottom_shell_layers", "top_shell_layers", "__unresolved_parents__"]:
    print(f"  {key:35s} = {effective.get(key)!r}")

print("\n=== get_setting (chave única) ===")
val = store.get_effective_value("process", "0.20mm Standard @Anycubic Kobra S1 0.4 nozzle", "support_top_z_distance")
print(f"  support_top_z_distance = {val}")

print("\n=== get_settings (grupo de suporte) ===")
support_keys = [k for k in effective if k.startswith("support_")]
grouped = store.get_effective_values("process", "0.20mm Standard @Anycubic Kobra S1 0.4 nozzle", support_keys)
for k, v in sorted(grouped.items()):
    print(f"  {k:35s} = {v!r}")

# --- clonagem + propose + validate + apply + rollback --------------------
writer = UserPresetWriter(USER_ROOT)

print("\n=== clone_profile ===")
clone_path = writer.clone(
    store, "process", "0.20mm Standard @Anycubic Kobra S1 0.4 nozzle", "Chaveiro_SemiReforcado_teste"
)
print(f"  criado em: {clone_path}")

# Reindexar a store para enxergar o novo preset de usuário
store = PresetStore([("system:Anycubic", SYSTEM_ROOT), ("user", USER_ROOT)])

print("\n=== propose_profile_patch (suporte muito preso -> afrouxar) ===")
proposal = writer.propose_patch(
    store, "process", "Chaveiro_SemiReforcado_teste",
    {"support_top_z_distance": "0.32", "support_interface_top_layers": "1"},
)
for key, (before, after) in proposal["diff"].items():
    print(f"  {key}: {before} -> {after}")

print("\n=== validate_profile_patch ===")
catalog = seed_catalog()
problems = writer.validate_patch("process", proposal["changes"], catalog)
print("  problemas:", problems if problems else "nenhum — patch válido")

print("\n=== apply_profile_patch ===")
applied_path = writer.apply_patch("process", "Chaveiro_SemiReforcado_teste", proposal["changes"])
print(f"  aplicado em: {applied_path}")

store = PresetStore([("system:Anycubic", SYSTEM_ROOT), ("user", USER_ROOT)])
effective_after = store.resolve("process", "Chaveiro_SemiReforcado_teste")
print(f"  support_top_z_distance agora = {effective_after['support_top_z_distance']}")

print("\n=== rollback_profile ===")
writer.rollback("process", "Chaveiro_SemiReforcado_teste")
store = PresetStore([("system:Anycubic", SYSTEM_ROOT), ("user", USER_ROOT)])
effective_rolled_back = store.resolve("process", "Chaveiro_SemiReforcado_teste")
print(f"  support_top_z_distance após rollback = {effective_rolled_back.get('support_top_z_distance', '<herdado, sem override>')}")

# --- export/import de bundle ----------------------------------------------
print("\n=== export_anycubic_bundle (.orca_printer real, zip) ===")
_, printer_path = store.find_path("machine", "Anycubic Kobra S1 0.4 nozzle")
_, filament_path = store.find_path("filament", "Anycubic PLA @Anycubic Kobra S1 0.4 nozzle")
_, process_path = store.find_path("process", "0.20mm Standard @Anycubic Kobra S1 0.4 nozzle")

bundle_out = WORK / "Anycubic Kobra S1 0.4 nozzle.orca_printer"
export_bundle(bundle_out, printer_path, [filament_path], [process_path], bundle_id="teste_local_001")
print(f"  bundle criado: {bundle_out} ({bundle_out.stat().st_size} bytes)")

print("\n=== import_anycubic_bundle (round-trip) ===")
imported = import_bundle(bundle_out)
print(f"  bundle_type   = {imported.bundle_structure['bundle_type']}")
print(f"  printer.name  = {imported.printer['name']}")
print(f"  filaments     = {[f['name'] for f in imported.filaments]}")
print(f"  processes     = {[p['name'] for p in imported.processes]}")

print("\n✅ Todos os testes rodaram sem exceções.")
