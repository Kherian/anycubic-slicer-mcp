"""
slicing_engine.py
==================

Fatiamento real (headless, sem interface gráfica) via linha de comando do
Anycubic Slicer Next (ou qualquer binário compatível da família OrcaSlicer).

Validado (checklist honesto):
- Testado de ponta a ponta com o OrcaSlicer oficial 2.4.2 (Linux) em ambiente
  sem display: `--info`, `--slice`, `--load-settings`, `--load-filaments`,
  `--export-3mf`, `--datadir`, `--outputdir` funcionam exatamente como
  documentado.
- Confirmado que o AnycubicSlicerNext.app real do usuário preserva TODAS
  essas flags (`--help` rodado na máquina real, saída idêntica em estrutura).
- NÃO testado ainda contra um binário real fatiando um preset customizado
  do usuário (ex.: "Chaveiro Reforçado") — testado apenas com presets
  oficiais de exemplo (BBL). A lógica de resolução de presets já foi
  validada à parte em preset_engine.py.

Cada chamada usa um --datadir e --outputdir TEMPORÁRIOS E DESCARTÁVEIS,
isolados da instalação real do usuário — nunca toca no perfil ativo nem
na sessão do programa aberto.
"""

from __future__ import annotations

import json
import re
import shutil
import subprocess
import tempfile
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional


class SlicingError(Exception):
    pass


class SlicerBinaryNotFoundError(SlicingError):
    pass


class SlicingTimeoutError(SlicingError):
    pass


@dataclass
class ModelInfo:
    file: str
    size_x: float
    size_y: float
    size_z: float
    number_of_facets: int
    number_of_parts: int
    volume_mm3: float
    manifold: bool
    raw: Dict[str, str] = field(default_factory=dict)


@dataclass
class SliceResult:
    success: bool
    error_string: str
    label: Optional[str] = None
    layer_height: Optional[float] = None
    sparse_infill_density: Optional[float] = None
    wall_loops: Optional[int] = None
    printing_time_str: Optional[str] = None
    printing_time_minutes: Optional[float] = None
    filament_used_mm: Optional[float] = None
    filament_used_cm3: Optional[float] = None
    filament_used_g: Optional[float] = None
    warnings: List[str] = field(default_factory=list)
    raw_result_json: Optional[Dict[str, Any]] = None
    stdout_tail: Optional[str] = None
    command: Optional[str] = None


_INFO_LINE_RE = re.compile(r"^(\w+)\s*=\s*(.+)$")
_TIME_RE = re.compile(
    r"model printing time:\s*(?P<model>[^;]+);\s*total estimated time:\s*(?P<total>.+)"
)
_FIL_MM_RE = re.compile(r"filament used \[mm\]\s*=\s*([\d.]+)")
_FIL_CM3_RE = re.compile(r"filament used \[cm3\]\s*=\s*([\d.]+)")


def _parse_duration_to_minutes(text: str) -> Optional[float]:
    """Converte strings tipo '1h 23m 4s' ou '11m 38s' para minutos (float)."""
    text = text.strip()
    total_seconds = 0.0
    for value, unit in re.findall(r"(\d+(?:\.\d+)?)\s*([hms])", text):
        value = float(value)
        if unit == "h":
            total_seconds += value * 3600
        elif unit == "m":
            total_seconds += value * 60
        elif unit == "s":
            total_seconds += value
    return round(total_seconds / 60, 2) if total_seconds else None


def get_model_info(binary_path: str, model_path: Path, timeout: float = 60.0) -> ModelInfo:
    """Roda `--info` no arquivo (STL ou 3MF) SEM fatiar — leitura pura de
    geometria: dimensões, contagem de triângulos, se a malha é manifold."""
    if not Path(binary_path).exists():
        raise SlicerBinaryNotFoundError(f"Binário do slicer não encontrado em: {binary_path}")
    if not Path(model_path).exists():
        raise SlicingError(f"Arquivo de modelo não encontrado: {model_path}")

    try:
        proc = subprocess.run(
            [binary_path, "--info", str(model_path)],
            capture_output=True, text=True, timeout=timeout,
        )
    except subprocess.TimeoutExpired:
        raise SlicingTimeoutError(f"--info excedeu {timeout}s")

    raw: Dict[str, str] = {}
    for line in proc.stdout.splitlines():
        m = _INFO_LINE_RE.match(line.strip())
        if m:
            raw[m.group(1)] = m.group(2)

    if not raw:
        raise SlicingError(
            f"Não foi possível interpretar a saída de --info. "
            f"stdout={proc.stdout!r} stderr={proc.stderr!r}"
        )

    return ModelInfo(
        file=str(model_path),
        size_x=float(raw.get("size_x", 0)),
        size_y=float(raw.get("size_y", 0)),
        size_z=float(raw.get("size_z", 0)),
        number_of_facets=int(raw.get("number_of_facets", 0)),
        number_of_parts=int(raw.get("number_of_parts", "1").strip()),
        volume_mm3=float(raw.get("volume", 0)),
        manifold=raw.get("manifold", "").strip().lower() == "yes",
        raw=raw,
    )


def slice_model(
    binary_path: str,
    model_path: Path,
    machine_preset_path: Path,
    process_preset_path: Path,
    filament_preset_paths: List[Path],
    filament_density_g_cm3: Optional[float] = None,
    label: Optional[str] = None,
    timeout: float = 180.0,
    extra_args: Optional[List[str]] = None,
) -> SliceResult:
    """
    Fatia de verdade, em um --datadir/--outputdir temporário e descartável.

    filament_density_g_cm3: se fornecido (normalmente lido do próprio
    preset de filamento via preset_engine.resolve), é usado para converter
    o volume de filamento gasto (cm3, sempre presente no G-code) em gramas.
    """
    if not Path(binary_path).exists():
        raise SlicerBinaryNotFoundError(f"Binário do slicer não encontrado em: {binary_path}")
    if not Path(model_path).exists():
        raise SlicingError(f"Arquivo de modelo não encontrado: {model_path}")

    tmp_root = Path(tempfile.mkdtemp(prefix="asn_slice_"))
    datadir = tmp_root / "datadir"
    outputdir = tmp_root / "out"
    logfile = tmp_root / "debug.log"
    datadir.mkdir(parents=True, exist_ok=True)
    outputdir.mkdir(parents=True, exist_ok=True)

    settings_arg = f"{machine_preset_path};{process_preset_path}"
    filaments_arg = ";".join(str(p) for p in filament_preset_paths)

    cmd = [
        binary_path,
        "--datadir", str(datadir),
        "--outputdir", str(outputdir),
        "--load-settings", settings_arg,
        "--load-filaments", filaments_arg,
        "--slice", "1",
        "--export-3mf", "result.gcode.3mf",
        "--debug", "3",
        "--logfile", str(logfile),
    ]
    if extra_args:
        cmd.extend(extra_args)
    cmd.append(str(model_path))

    try:
        proc = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout, cwd=str(tmp_root))
    except subprocess.TimeoutExpired:
        shutil.rmtree(tmp_root, ignore_errors=True)
        raise SlicingTimeoutError(f"Fatiamento excedeu {timeout}s — modelo pode ser muito complexo.")

    result_json_path = outputdir / "result.json"
    raw_result: Optional[Dict[str, Any]] = None
    if result_json_path.exists():
        try:
            raw_result = json.loads(result_json_path.read_text(encoding="utf-8"))
        except json.JSONDecodeError:
            raw_result = None

    success = bool(raw_result and raw_result.get("error_string", "").lower().startswith("success"))

    # O binário quase sempre fica em silêncio no stdout/stderr — os detalhes
    # reais (inclusive o motivo de uma falha silenciosa) ficam no --logfile.
    diag_parts = []
    if proc.stdout.strip() or proc.stderr.strip():
        diag_parts.append("\n".join((proc.stdout + proc.stderr).splitlines()[-20:]))
    if logfile.exists():
        log_tail = "\n".join(logfile.read_text(encoding="utf-8", errors="ignore").splitlines()[-40:])
        diag_parts.append(f"--- últimas linhas de {logfile.name} ---\n{log_tail}")
    diag_text = "\n\n".join(diag_parts) if diag_parts else "(sem saída de diagnóstico nem log — verifique se o binário rodou de todo)"

    result = SliceResult(
        success=success,
        error_string=(raw_result or {}).get("error_string", "sem result.json — ver stdout_tail"),
        label=label,
        layer_height=(raw_result or {}).get("layer_height"),
        sparse_infill_density=(raw_result or {}).get("sparse_infill_density"),
        wall_loops=(raw_result or {}).get("wall_loops"),
        raw_result_json=raw_result,
        stdout_tail=diag_text,
        command=" ".join(cmd),
    )

    if raw_result:
        for plate in raw_result.get("sliced_plates", []):
            if plate.get("warning_message"):
                result.warnings.append(plate["warning_message"])

    gcode_path = outputdir / "plate_1.gcode"
    if gcode_path.exists():
        full_text = gcode_path.read_text(encoding="utf-8", errors="ignore")
        # Tempo total fica no HEADER (início do arquivo).
        header = full_text[:4000]
        time_match = _TIME_RE.search(header)
        if time_match:
            result.printing_time_str = time_match.group("total").strip()
            result.printing_time_minutes = _parse_duration_to_minutes(time_match.group("total"))
        # Consumo de filamento fica no FOOTER (fim do arquivo) — descoberto
        # empiricamente: não é documentado, e pode variar entre versões.
        footer = full_text[-4000:]
        mm_match = _FIL_MM_RE.search(footer)
        if mm_match:
            result.filament_used_mm = float(mm_match.group(1))
        cm3_match = _FIL_CM3_RE.search(footer)
        if cm3_match:
            result.filament_used_cm3 = float(cm3_match.group(1))
            if filament_density_g_cm3:
                result.filament_used_g = round(result.filament_used_cm3 * filament_density_g_cm3, 2)

    shutil.rmtree(tmp_root, ignore_errors=True)
    return result


def compare_slice_configs(
    binary_path: str,
    model_path: Path,
    configs: List[Dict[str, Any]],
    timeout_per_config: float = 180.0,
) -> List[SliceResult]:
    """
    configs: lista de dicts, cada um com:
      {"label": str, "machine_preset_path": Path, "process_preset_path": Path,
       "filament_preset_paths": [Path, ...], "filament_density_g_cm3": float|None}
    Roda slice_model para cada config e devolve a lista de resultados, na
    mesma ordem, para comparação lado a lado.
    """
    results = []
    for cfg in configs:
        try:
            r = slice_model(
                binary_path=binary_path,
                model_path=model_path,
                machine_preset_path=cfg["machine_preset_path"],
                process_preset_path=cfg["process_preset_path"],
                filament_preset_paths=cfg["filament_preset_paths"],
                filament_density_g_cm3=cfg.get("filament_density_g_cm3"),
                label=cfg.get("label"),
                timeout=timeout_per_config,
            )
        except SlicingError as e:
            r = SliceResult(success=False, error_string=str(e), label=cfg.get("label"))
        results.append(r)
    return results
