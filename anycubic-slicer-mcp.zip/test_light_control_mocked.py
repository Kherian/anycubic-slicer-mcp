"""
Teste em MODELO CONTROLADO (mock) do light_control.py — sem rede, sem
impressora real. Isso valida que o código constrói as chamadas certas e
lida com os casos de erro esperados. NÃO substitui o teste com hardware.
"""
import asyncio
import sys
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock

sys.path.insert(0, str(Path(__file__).parent))
from asn_mcp.experimental.light_control import (  # noqa: E402
    LightNotSupportedError,
    get_light_capabilities,
    set_chamber_light,
)


def make_fake_printer(supports_box=True, supports_video=False, has_project=True):
    printer = MagicMock()
    printer.supports_function_box_light = supports_box
    printer.supports_function_video_light = supports_video
    printer.connected_peripherals = ["box_light"] if supports_box else []
    printer.update_info_from_api = AsyncMock()
    fake_project = MagicMock() if has_project else None
    printer.latest_project = fake_project
    return printer


def make_fake_api(printer):
    api = MagicMock()
    api.printer_info_for_id = AsyncMock(return_value=printer)
    api._send_order_set_light_status = AsyncMock(
        return_value={"data": {"msgid": "fake-msg-123"}}
    )
    api._send_order_get_light_status = AsyncMock(return_value=None)
    return api


async def run_tests():
    print("=== Teste 1: capacidades (read-only) ===")
    printer = make_fake_printer(supports_box=True)
    api = make_fake_api(printer)
    caps = await get_light_capabilities(api, printer_id=123)
    print(f"  supports_box_light={caps.supports_box_light} supports_video_light={caps.supports_video_light}")
    assert caps.supports_box_light is True

    print("\n=== Teste 2: set_chamber_light com suporte declarado ===")
    result = await set_chamber_light(api, printer_id=123, light_on=True, confirm_timeout_s=0.01)
    print(f"  order_sent={result.order_sent} msg_id={result.order_msg_id}")
    print(f"  warning={result.warning}")
    api._send_order_set_light_status.assert_awaited_once()
    called_kwargs = api._send_order_set_light_status.call_args.kwargs
    assert called_kwargs["light_on"] is True
    assert called_kwargs["light_type"] == 2  # LIGHT_TYPE_BOX default
    print("  ✅ chamada construída com os parâmetros esperados")

    print("\n=== Teste 3: recusa quando a impressora NÃO anuncia suporte ===")
    printer_no_support = make_fake_printer(supports_box=False, supports_video=False)
    api_no_support = make_fake_api(printer_no_support)
    try:
        await set_chamber_light(api_no_support, printer_id=456, light_on=True, confirm_timeout_s=0.01)
        print("  ❌ FALHOU: deveria ter recusado")
        raise SystemExit(1)
    except LightNotSupportedError as e:
        print(f"  ✅ recusou corretamente: {e}")

    print("\n=== Teste 4: sem projeto associado (limite real do protocolo) ===")
    printer_no_project = make_fake_printer(supports_box=True, has_project=False)
    api_no_project = make_fake_api(printer_no_project)
    try:
        await set_chamber_light(api_no_project, printer_id=789, light_on=False, confirm_timeout_s=0.01)
        print("  ❌ FALHOU: deveria ter levantado erro de falta de projeto")
        raise SystemExit(1)
    except Exception as e:
        print(f"  ✅ erro esperado e claro: {e}")

    print("\n✅ Todos os testes em modelo controlado passaram.")
    print("⚠️  Isso NÃO confirma que funciona na Kobra S1 real — só que o código")
    print("   não quebra e monta as chamadas certas. O teste real é no hardware.")


asyncio.run(run_tests())
