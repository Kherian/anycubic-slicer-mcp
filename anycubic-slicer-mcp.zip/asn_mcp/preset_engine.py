"""
preset_engine.py
=================

Motor de leitura, resolução e edição segura de presets do Anycubic Slicer Next
(derivado do OrcaSlicer / Bambu Studio / PrusaSlicer).

Este módulo NÃO depende de nenhuma instalação real do Anycubic Slicer Next para
funcionar: ele opera sobre diretórios de presets no formato oficial (JSON com
"type", "name", "inherits" etc.), que é o mesmo formato usado tanto pelos
presets "system" (os que vêm com o programa, em resources/profiles/<Vendor>/)
quanto pelos presets "user" (os que o usuário cria, geralmente em
~/.config/<AppKey>/user/<user_id>/{machine,filament,process}/).

Conceitos:

- PresetRef: identifica um preset por (tipo, nome).
- PresetStore: indexa vários diretórios-raiz (roots) em ordem de prioridade
  (ex.: primeiro "user", depois "system") e permite localizar e carregar
  qualquer preset pelo nome, dentro de um tipo.
- resolve(): resolve a cadeia de "inherits" recursivamente e devolve o dict
  de valores efetivos finais (igual ao que o slicer usa internamente),
  preservando também a cadeia (para nunca "achatar" sem necessidade).
- Operações de escrita (clone, propose/validate/apply patch, rollback) atuam
  SEMPRE sobre o diretório de presets do usuário, nunca sobre os presets
  "system" — isso é o análogo direto da separação READ/PROPOSE/APPLY exigida
  na especificação do projeto.
"""

from __future__ import annotations

import json
import shutil
import time
import zipfile
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

PRESET_TYPES = ("machine", "filament", "process")

# Chaves de metadado do preset (não são parâmetros de impressão/máquina).
# Não entram em "diffs" de configuração nem são candidatas a patch.
METADATA_KEYS = {
    "type",
    "name",
    "inherits",
    "from",
    "setting_id",
    "instantiation",
    "is_custom_defined",
    "printer_settings_id",
    "print_settings_id",
    "filament_settings_id",
}

BUNDLE_STRUCTURE_JSON_NAME = "bundle_structure.json"


class PresetError(Exception):
    pass


class PresetNotFoundError(PresetError):
    pass


class PresetValidationError(PresetError):
    pass


@dataclass
class PresetRef:
    type: str  # "machine" | "filament" | "process"
    name: str

    def __post_init__(self):
        if self.type not in PRESET_TYPES:
            raise PresetError(f"Tipo de preset inválido: {self.type!r}")


@dataclass
class PresetRecord:
    ref: PresetRef
    path: Path
    raw: Dict[str, Any]
    root_label: str  # de qual root (ex.: "user", "system:Anycubic") veio


class PresetStore:
    """
    Indexa um ou mais diretórios-raiz de presets.

    Cada root é uma tupla (label, base_dir). Dentro de base_dir espera-se
    encontrar subpastas "machine/", "filament/", "process/" com arquivos
    .json (é exatamente a estrutura usada tanto por
    resources/profiles/<Vendor>/ quanto pela pasta de presets do usuário).

    A ordem dos roots importa: o primeiro root que contiver um preset com
    aquele nome "vence" (isso modela o comportamento real: presets do
    usuário sobrepõem presets de sistema com o mesmo nome).
    """

    def __init__(self, roots: List[Tuple[str, Path]]):
        self.roots = [(label, Path(p)) for label, p in roots]
        self._index: Dict[str, Dict[str, Tuple[str, Path]]] = {
            t: {} for t in PRESET_TYPES
        }
        self._build_index()

    def _build_index(self) -> None:
        # Percorre em ordem REVERSA para que os roots de maior prioridade
        # (os primeiros da lista) sobrescrevam os de menor prioridade no dict.
        for label, base in reversed(self.roots):
            for ptype in PRESET_TYPES:
                type_dir = base / ptype
                if not type_dir.is_dir():
                    continue
                for jf in type_dir.rglob("*.json"):
                    try:
                        with open(jf, "r", encoding="utf-8") as fh:
                            data = json.load(fh)
                    except (json.JSONDecodeError, OSError):
                        continue
                    name = data.get("name") or jf.stem
                    self._index[ptype][name] = (label, jf)

    def list_names(self, ptype: str) -> List[str]:
        if ptype not in PRESET_TYPES:
            raise PresetError(f"Tipo inválido: {ptype}")
        return sorted(self._index[ptype].keys())

    def find_path(self, ptype: str, name: str) -> Tuple[str, Path]:
        try:
            return self._index[ptype][name]
        except KeyError:
            raise PresetNotFoundError(f"Preset {ptype}:{name!r} não encontrado")

    def load_raw(self, ptype: str, name: str) -> PresetRecord:
        label, path = self.find_path(ptype, name)
        with open(path, "r", encoding="utf-8") as fh:
            raw = json.load(fh)
        return PresetRecord(ref=PresetRef(ptype, name), path=path, raw=raw, root_label=label)

    def resolve(self, ptype: str, name: str, _seen: Optional[List[str]] = None) -> Dict[str, Any]:
        """
        Resolve a cadeia de 'inherits' e devolve o dict de valores efetivos.
        O preset filho sempre sobrescreve os valores do pai. Detecta ciclos.
        """
        _seen = _seen or []
        if name in _seen:
            raise PresetError(f"Ciclo de 'inherits' detectado: {' -> '.join(_seen + [name])}")
        record = self.load_raw(ptype, name)
        raw = dict(record.raw)
        parent_name = raw.get("inherits")

        if parent_name:
            # 'inherits' pode ser uma string única (mais comum) — se algum
            # dia vier lista, resolvemos em ordem e o filho ainda vence.
            parent_names = parent_name if isinstance(parent_name, list) else [parent_name]
            merged: Dict[str, Any] = {}
            for pname in parent_names:
                try:
                    parent_effective = self.resolve(ptype, pname, _seen + [name])
                    merged.update(parent_effective)
                except PresetNotFoundError:
                    # Preset-base "comum" (ex.: fdm_process_common) pode não
                    # existir no root filtrado (ex.: só copiamos um vendor
                    # específico); nesse caso seguimos sem ele, mas
                    # sinalizamos isso no resultado.
                    merged.setdefault("__unresolved_parents__", [])
                    merged["__unresolved_parents__"].append(pname)
            merged.update(raw)
            return merged

        return raw

    def get_effective_value(self, ptype: str, name: str, key: str) -> Any:
        effective = self.resolve(ptype, name)
        if key not in effective:
            raise PresetError(f"Chave {key!r} não encontrada (nem no preset, nem na cadeia de inherits)")
        return effective[key]

    def get_effective_values(self, ptype: str, name: str, keys: List[str]) -> Dict[str, Any]:
        effective = self.resolve(ptype, name)
        return {k: effective.get(k, None) for k in keys}


def diff_effective(a: Dict[str, Any], b: Dict[str, Any]) -> Dict[str, Tuple[Any, Any]]:
    """Compara dois dicts de valores efetivos, ignorando chaves de metadado."""
    keys = (set(a) | set(b)) - METADATA_KEYS - {"__unresolved_parents__"}
    out = {}
    for k in sorted(keys):
        va, vb = a.get(k, "<ausente>"), b.get(k, "<ausente>")
        if va != vb:
            out[k] = (va, vb)
    return out


class UserPresetWriter:
    """
    Responsável por TODAS as operações de escrita (clone, patch, rollback).
    Atua exclusivamente dentro de um diretório de presets do usuário
    (nunca sobre presets "system"), e mantém histórico versionado por preset
    em uma subpasta oculta '.asn_mcp_history/'.
    """

    def __init__(self, user_root: Path):
        self.user_root = Path(user_root)
        for t in PRESET_TYPES:
            (self.user_root / t).mkdir(parents=True, exist_ok=True)
        self.history_dir = self.user_root / ".asn_mcp_history"
        self.history_dir.mkdir(parents=True, exist_ok=True)

    def _preset_path(self, ptype: str, name: str) -> Path:
        return self.user_root / ptype / f"{name}.json"

    def clone(self, store: PresetStore, ptype: str, source_name: str, new_name: str) -> Path:
        """Cria um novo preset de usuário que HERDA do original (não copia
        todos os valores — preserva a cadeia de inherits, como a spec exige)."""
        if new_name in store.list_names(ptype):
            raise PresetError(f"Já existe um preset {ptype}:{new_name!r}")
        new_raw = {
            "type": ptype,
            "name": new_name,
            "inherits": source_name,
            "from": "user",
            "instantiation": "true",
        }
        out_path = self._preset_path(ptype, new_name)
        with open(out_path, "w", encoding="utf-8") as fh:
            json.dump(new_raw, fh, indent=4, ensure_ascii=False)
        return out_path

    def propose_patch(
        self, store: PresetStore, ptype: str, name: str, changes: Dict[str, Any]
    ) -> Dict[str, Any]:
        """Não escreve nada. Apenas calcula before/after para revisão humana."""
        effective_before = store.resolve(ptype, name)
        effective_after = dict(effective_before)
        effective_after.update(changes)
        return {
            "preset": {"type": ptype, "name": name},
            "changes": changes,
            "diff": diff_effective(effective_before, effective_after),
        }

    def validate_patch(
        self, ptype: str, changes: Dict[str, Any], catalog: "SemanticCatalog"
    ) -> List[str]:
        """Validação contextual básica usando o catálogo semântico.
        Devolve lista de problemas (vazia = ok)."""
        problems = []
        for key, value in changes.items():
            entry = catalog.by_key.get(key)
            if entry is None:
                problems.append(
                    f"Chave '{key}' não está no catálogo semântico — revisar manualmente antes de aplicar."
                )
                continue
            if entry.namespace != ptype:
                problems.append(
                    f"Chave '{key}' pertence ao namespace '{entry.namespace}', "
                    f"não a '{ptype}'. Recusado (regra: não alterar propriedades no namespace errado)."
                )
            if entry.min_value is not None or entry.max_value is not None:
                try:
                    numeric = float(str(value).rstrip("%"))
                except ValueError:
                    problems.append(f"Chave '{key}': valor '{value}' não é numérico, esperado número.")
                else:
                    if entry.min_value is not None and numeric < entry.min_value:
                        problems.append(f"Chave '{key}': {numeric} abaixo do mínimo ({entry.min_value}).")
                    if entry.max_value is not None and numeric > entry.max_value:
                        problems.append(f"Chave '{key}': {numeric} acima do máximo ({entry.max_value}).")
        return problems

    def apply_patch(self, ptype: str, name: str, changes: Dict[str, Any]) -> Path:
        """Aplica de fato, criando backup versionado antes de gravar."""
        path = self._preset_path(ptype, name)
        if path.exists():
            with open(path, "r", encoding="utf-8") as fh:
                current = json.load(fh)
        else:
            raise PresetError(
                f"Preset de usuário {ptype}:{name!r} não existe. "
                f"Use 'clone' primeiro — não se edita preset 'system' diretamente."
            )

        self._backup(ptype, name, current)

        updated = dict(current)
        updated.update(changes)
        with open(path, "w", encoding="utf-8") as fh:
            json.dump(updated, fh, indent=4, ensure_ascii=False)

        metadata = {
            "timestamp": time.time(),
            "preset_type": ptype,
            "preset_name": name,
            "changed_keys": list(changes.keys()),
            "previous_values": {k: current.get(k) for k in changes},
            "new_values": changes,
        }
        self._write_metadata(ptype, name, metadata)
        return path

    def _backup(self, ptype: str, name: str, current_raw: Dict[str, Any]) -> Path:
        stamp = time.strftime("%Y%m%dT%H%M%S")
        backup_path = self.history_dir / f"{ptype}__{name}__{stamp}.before.json"
        with open(backup_path, "w", encoding="utf-8") as fh:
            json.dump(current_raw, fh, indent=4, ensure_ascii=False)
        return backup_path

    def _write_metadata(self, ptype: str, name: str, metadata: Dict[str, Any]) -> Path:
        stamp = time.strftime("%Y%m%dT%H%M%S")
        meta_path = self.history_dir / f"{ptype}__{name}__{stamp}.metadata.json"
        with open(meta_path, "w", encoding="utf-8") as fh:
            json.dump(metadata, fh, indent=4, ensure_ascii=False)
        return meta_path

    def list_history(self, ptype: str, name: str) -> List[Path]:
        pattern = f"{ptype}__{name}__*.before.json"
        return sorted(self.history_dir.glob(pattern))

    def rollback(self, ptype: str, name: str) -> Path:
        backups = self.list_history(ptype, name)
        if not backups:
            raise PresetError(f"Não há backup para {ptype}:{name!r}")
        latest = backups[-1]
        with open(latest, "r", encoding="utf-8") as fh:
            previous_raw = json.load(fh)
        path = self._preset_path(ptype, name)
        with open(path, "w", encoding="utf-8") as fh:
            json.dump(previous_raw, fh, indent=4, ensure_ascii=False)
        latest.unlink()  # backup consumido
        return path


# ---------------------------------------------------------------------------
# Bundle .orca_printer / .anycubic_printer
# ---------------------------------------------------------------------------
#
# Formato real (confirmado no código-fonte oficial, CreatePresetsDialog.cpp):
# um ZIP contendo:
#   printer/<Nome da máquina>.json
#   filament/<Nome do filamento>.json  (um ou mais)
#   process/<Nome do processo>.json    (um ou mais)
#   bundle_structure.json  -> {
#       "version": ..., "bundle_id": ..., "bundle_type": "printer config bundle",
#       "printer_preset_name": ...,
#       "printer_config": ["printer/Nome.json"],
#       "filament_config": ["filament/Nome1.json", ...],
#       "process_config": ["process/Nome1.json", ...]
#   }


def export_bundle(
    out_path: Path,
    printer_preset_path: Path,
    filament_preset_paths: List[Path],
    process_preset_paths: List[Path],
    bundle_id: str,
) -> Path:
    out_path = Path(out_path)
    bundle_structure = {
        "version": "",
        "bundle_id": bundle_id,
        "bundle_type": "printer config bundle",
        "printer_preset_name": printer_preset_path.stem,
        "printer_config": [f"printer/{printer_preset_path.name}"],
        "filament_config": [f"filament/{p.name}" for p in filament_preset_paths],
        "process_config": [f"process/{p.name}" for p in process_preset_paths],
    }
    with zipfile.ZipFile(out_path, "w", zipfile.ZIP_DEFLATED) as zf:
        zf.write(printer_preset_path, f"printer/{printer_preset_path.name}")
        for p in filament_preset_paths:
            zf.write(p, f"filament/{p.name}")
        for p in process_preset_paths:
            zf.write(p, f"process/{p.name}")
        zf.writestr(BUNDLE_STRUCTURE_JSON_NAME, json.dumps(bundle_structure, ensure_ascii=False))
    return out_path


@dataclass
class ImportedBundle:
    bundle_structure: Dict[str, Any]
    printer: Dict[str, Any]
    filaments: List[Dict[str, Any]]
    processes: List[Dict[str, Any]]


def import_bundle(bundle_path: Path) -> ImportedBundle:
    bundle_path = Path(bundle_path)
    with zipfile.ZipFile(bundle_path, "r") as zf:
        names = zf.namelist()
        if BUNDLE_STRUCTURE_JSON_NAME not in names:
            raise PresetValidationError(
                f"Bundle inválido: falta '{BUNDLE_STRUCTURE_JSON_NAME}' — não é um "
                f".orca_printer/.anycubic_printer reconhecível."
            )
        structure = json.loads(zf.read(BUNDLE_STRUCTURE_JSON_NAME).decode("utf-8"))

        def _load_all(key: str) -> List[Dict[str, Any]]:
            out = []
            for rel in structure.get(key, []):
                if rel not in names:
                    raise PresetValidationError(f"Bundle corrompido: {rel} listado mas ausente no zip")
                out.append(json.loads(zf.read(rel).decode("utf-8")))
            return out

        printer_list = _load_all("printer_config")
        if not printer_list:
            raise PresetValidationError("Bundle sem printer_config")
        return ImportedBundle(
            bundle_structure=structure,
            printer=printer_list[0],
            filaments=_load_all("filament_config"),
            processes=_load_all("process_config"),
        )


# ---------------------------------------------------------------------------
# Catálogo semântico PT-BR <-> chave JSON
# ---------------------------------------------------------------------------


@dataclass
class CatalogEntry:
    pt_name: str
    key: str
    namespace: str  # "machine" | "filament" | "process"
    category: str
    value_type: str  # "float" | "int" | "percent" | "enum" | "string" | "bool" | "list"
    unit: Optional[str] = None
    min_value: Optional[float] = None
    max_value: Optional[float] = None
    depends_on: List[str] = field(default_factory=list)
    notes: Optional[str] = None


class SemanticCatalog:
    """Camada de mapeamento Nome PT-BR <-> conceito <-> chave JSON <-> tipo/unidade/limites.

    Este é o catálogo SEMENTE (seed), derivado dos próprios presets oficiais
    e da lista de exemplos da especificação. Ele deve crescer organicamente,
    entrada por entrada, sempre lastreado em presets/código reais — nunca por
    adivinhação (conforme exigido na spec).
    """

    def __init__(self, entries: Optional[List[CatalogEntry]] = None):
        self.entries: List[CatalogEntry] = entries or []
        self._reindex()

    def _reindex(self):
        self.by_key: Dict[str, CatalogEntry] = {e.key: e for e in self.entries}
        self.by_pt_name: Dict[str, CatalogEntry] = {e.pt_name.lower(): e for e in self.entries}

    def add(self, entry: CatalogEntry) -> None:
        self.entries.append(entry)
        self._reindex()

    def resolve_pt_name(self, pt_name: str) -> Optional[CatalogEntry]:
        return self.by_pt_name.get(pt_name.lower())

    def to_json(self) -> List[Dict[str, Any]]:
        return [e.__dict__ for e in self.entries]

    @classmethod
    def load_json(cls, path: Path) -> "SemanticCatalog":
        with open(path, "r", encoding="utf-8") as fh:
            raw = json.load(fh)
        return cls([CatalogEntry(**e) for e in raw])

    def save_json(self, path: Path) -> None:
        with open(path, "w", encoding="utf-8") as fh:
            json.dump(self.to_json(), fh, indent=2, ensure_ascii=False)


def seed_catalog() -> SemanticCatalog:
    """Catálogo inicial — todas as chaves abaixo foram conferidas nos presets
    oficiais reais 'process/0.20mm Standard @Anycubic Kobra S1 0.4 nozzle.json'
    e 'machine/Anycubic Kobra S1 0.4 nozzle.json' do repositório oficial."""
    entries = [
        CatalogEntry("Ativar suporte", "enable_support", "process", "suporte", "bool"),
        CatalogEntry("Tipo de suporte", "support_type", "process", "suporte", "enum"),
        CatalogEntry("Distância Z superior do suporte", "support_top_z_distance", "process", "suporte", "float", unit="mm", min_value=0),
        CatalogEntry("Distância Z inferior do suporte", "support_bottom_z_distance", "process", "suporte", "float", unit="mm", min_value=0),
        CatalogEntry("Distância XY entre suporte e objeto", "support_object_xy_distance", "process", "suporte", "float", unit="mm", min_value=0),
        CatalogEntry("Camadas de interface superior do suporte", "support_interface_top_layers", "process", "suporte", "int", min_value=0),
        CatalogEntry("Camadas de interface inferior do suporte", "support_interface_bottom_layers", "process", "suporte", "int", min_value=0),
        CatalogEntry("Espaçamento da interface de suporte", "support_interface_spacing", "process", "suporte", "float", unit="mm", min_value=0),
        CatalogEntry("Detectar paredes finas", "detect_thin_wall", "process", "paredes", "bool"),
        CatalogEntry("Número de paredes", "wall_loops", "process", "paredes", "int", min_value=0, depends_on=["line_width"]),
        CatalogEntry("Camadas superiores (top shell)", "top_shell_layers", "process", "casca", "int", min_value=0),
        CatalogEntry("Camadas inferiores (bottom shell)", "bottom_shell_layers", "process", "casca", "int", min_value=0),
        CatalogEntry("Densidade de preenchimento esparso", "sparse_infill_density", "process", "preenchimento", "percent", unit="%", min_value=0, max_value=100),
        CatalogEntry("Padrão de preenchimento esparso", "sparse_infill_pattern", "process", "preenchimento", "enum"),
        CatalogEntry("Altura da camada", "layer_height", "process", "qualidade", "float", unit="mm", min_value=0.04, depends_on=["nozzle_diameter"]),
        CatalogEntry("Largura de linha", "line_width", "process", "extrusão", "float", unit="mm", depends_on=["wall_loops", "nozzle_diameter"]),
        CatalogEntry("Velocidade de suporte", "support_speed", "process", "velocidade", "float", unit="mm/s", min_value=0),
        CatalogEntry("Fluxo de ponte", "bridge_flow", "process", "extrusão", "float"),
        CatalogEntry("Velocidade de ponte", "bridge_speed", "process", "velocidade", "float", unit="mm/s", min_value=0),
        CatalogEntry("Largura do brim", "brim_width", "process", "aderência", "float", unit="mm", min_value=0),
        CatalogEntry("Diâmetro do bico", "nozzle_diameter", "machine", "máquina", "list", unit="mm"),
        CatalogEntry("Altura máxima de camada", "max_layer_height", "machine", "máquina", "list", unit="mm"),
        CatalogEntry("Altura mínima de camada", "min_layer_height", "machine", "máquina", "list", unit="mm"),
        CatalogEntry("Ajuste de offset Z", "z_offset", "machine", "calibração", "float", unit="mm"),
        CatalogEntry("Sabor de G-code", "gcode_flavor", "machine", "firmware", "enum"),
    ]
    return SemanticCatalog(entries)
