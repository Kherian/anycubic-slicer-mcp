"""
experimental/light_server.py — MCP Server experimental de controle de luz

STATUS DESTE ARQUIVO: EXPERIMENTAL, NUNCA TESTADO EM HARDWARE REAL.
Câmera foi propositalmente DEIXADA DE FORA (ver README/histórico da
conversa): o token retornado por CAMERA_OPEN é uma credencial AWS-STS-like,
mas não há em nenhum lugar do código-fonte disponível a correlação com o
stream/canal do Kinesis Video Streams a que ela se refere — isso não é
"escrever mais código", é uma peça de protocolo que ninguém documentou
ainda. Reavaliar no futuro se surgir essa informação.

Depende do pacote `anycubic-cloud-mcp` já instalado (reaproveita
autenticação e client) — não duplica lógica de auth.

Configuração (mesmas variáveis do anycubic-cloud-mcp):
  ANYCUBIC_AUTH_MODE=slicer
  ANYCUBIC_TOKEN=<extraído com `anycubic-slicer-token`>

Tools expostas:
  get_light_capabilities(printer_id)      -> leitura, seguro
  set_chamber_light(printer_id, light_on) -> ESCRITA, experimental
"""

from __future__ import annotations

import logging

from anycubic_mcp.client import AnycubicClient
from anycubic_mcp.config import load_config
from mcp.server.mcpserver import MCPServer

from .light_control import (
    LightNotSupportedError,
    get_light_capabilities as _get_caps,
    set_chamber_light as _set_light,
)

logger = logging.getLogger("anycubic-light-experimental")

mcp = MCPServer(
    name="anycubic-light-experimental",
    version="0.1.0",
    instructions=(
        "EXPERIMENTAL: controle de luz da câmara, nunca validado em hardware "
        "real. Sempre chame get_light_capabilities antes de set_chamber_light. "
        "Se set_chamber_light retornar 'warning' preenchido, isso significa que "
        "o comando foi enviado mas NÃO foi confirmado — informe isso ao usuário "
        "explicitamente, não assuma sucesso."
    ),
)

_client: AnycubicClient | None = None


async def _get_client() -> AnycubicClient:
    global _client
    if _client is None:
        config = load_config()
        if not config.auth_mode or not config.auth_token:
            raise RuntimeError(
                "Sem autenticação configurada. Configure ANYCUBIC_AUTH_MODE e "
                "ANYCUBIC_TOKEN (mesmas variáveis do anycubic-cloud-mcp) ou rode "
                "`anycubic-slicer-token` para extrair o token do Slicer Next."
            )
        _client = AnycubicClient(config=config, logger=logger)
        await _client.start()
        await _client.ensure_auth()
    return _client


@mcp.tool()
async def get_light_capabilities(printer_id: int) -> dict:
    """[LEITURA] Verifica se a impressora anuncia suporte a luz de câmara
    (box_light) e/ou luz de vídeo (video_light) ANTES de tentar controlá-la.
    Sempre chame isto primeiro."""
    client = await _get_client()
    caps = await _get_caps(client.api, printer_id)
    return {
        "printer_id": caps.printer_id,
        "supports_box_light": caps.supports_box_light,
        "supports_video_light": caps.supports_video_light,
        "connected_peripherals": caps.connected_peripherals,
    }


@mcp.tool()
async def set_chamber_light(printer_id: int, light_on: bool) -> dict:
    """[ESCRITA — EXPERIMENTAL, NÃO VALIDADO] Tenta ligar/desligar a luz da
    câmara de impressão. O comando SET_LIGHT_STATUS existe no protocolo mas
    está marcado como não-testado na biblioteca original. Este tool SEMPRE
    tenta confirmar depois de enviar, e reporta honestamente via 'warning'
    quando não consegue confirmar — o que é esperado hoje, porque a
    confirmação chega de forma assíncrona via MQTT e esta versão não tem um
    listener plugado para capturá-la. Trate qualquer sucesso reportado aqui
    como 'comando enviado', não como 'luz definitivamente mudou de estado' —
    confirme visualmente com o usuário."""
    client = await _get_client()
    try:
        result = await _set_light(client.api, printer_id, light_on)
    except LightNotSupportedError as e:
        return {"ok": False, "error": str(e)}
    return {
        "ok": result.order_sent,
        "requested_state": result.requested_state,
        "order_msg_id": result.order_msg_id,
        "confirmed": result.confirmed_state,
        "warning": result.warning,
    }


def main() -> None:
    mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
