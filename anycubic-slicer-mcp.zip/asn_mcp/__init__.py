"""Anycubic Slicer Next MCP Server — leitura, comparação e edição segura de presets."""
__version__ = "0.1.0"
